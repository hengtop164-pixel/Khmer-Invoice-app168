import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Plus, Trash2, Search, Package, User, ShoppingBag,
  History, Edit3, CreditCard, Box, X, ArrowRight, CheckCircle,
  AlertCircle, TrendingDown, TrendingUp, Save, Pencil,
  LayoutDashboard, Menu, DollarSign,
  Phone, Clock, BadgeDollarSign, Lock, Settings, QrCode, Percent,
  Eye, EyeOff, Truck, Image as ImageIcon, ImageOff, Wallet, Receipt,
  ShieldCheck, Users, Check, Ban
} from 'lucide-react';

// Prevent mobile Safari/Chrome from auto-zooming the page when a text input
// is focused (fixes the "keyboard jumping / losing focus" issue on phones).
if (typeof document !== 'undefined') {
  let meta = document.querySelector('meta[name="viewport"]');
  if (!meta) {
    meta = document.createElement('meta');
    meta.name = 'viewport';
    document.head.appendChild(meta);
  }
  meta.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');
}

// Global typography — injected once at load so Khmer text renders cleanly
// on every screen (landing, login, signup, dashboard), not just after login.
if (typeof document !== 'undefined' && !document.getElementById('app-global-fonts')) {
  const link = document.createElement('link');
  link.id = 'app-global-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Khmer:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700;800;900&display=swap';
  document.head.appendChild(link);

  const style = document.createElement('style');
  style.id = 'app-global-style-rules';
  style.textContent = `
    * { font-family: 'Inter', 'Noto Sans Khmer', sans-serif; box-sizing: border-box; }
    .khmer, .khmer * { font-family: 'Noto Sans Khmer', 'Inter', sans-serif; line-height: 1.7; }
    input, select, textarea, button { font-size: 16px; }
    input[type=number]::-webkit-inner-spin-button { display: none; }
    @media print { .no-print { display: none !important; } }
  `;
  document.head.appendChild(style);
}

// ==================== Storage helpers ====================
// Local-first persistence via localStorage. The app is a white-label
// single-device tool, so per-device storage is the correct model.
async function loadKey(key: string, fallback: any) {
  try {
    const r = localStorage.getItem(key);
    return r ? JSON.parse(r) : fallback;
  } catch (e) { return fallback; }
}
async function saveKey(key: string, value: any) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch (e) { console.error('storage save failed', key, e); }
}

// ==================== Config (white-label — edit before distributing) ====================
const TRIAL_DAYS = 30;
const ADMIN_PIN = "2468"; // change this before giving the app to anyone
const SUBSCRIPTION_PRICE_USD = 2;
const SUBSCRIPTION_PAYEE_NAME = "SOK HENG PANG · ABA Bank";
const SUBSCRIPTION_QR_IMAGE = "";
const DEFAULT_RATES = { KHR: 4100, THB: 36 }; // units of currency per 1 USD
const CURRENCIES = [
  { code: 'USD', symbol: '$', decimals: 2 },
  { code: 'KHR', symbol: '\u17DB', decimals: 0 },
  { code: 'THB', symbol: '\u0E3F', decimals: 0 }
];
const UNITS = ['PCS', 'KG', 'BOX', 'HOUR', 'SERVICE', 'SHIPPING', 'OTHER'];

// ==================== Date + currency helpers ====================
function addDays(dateStr: string, days: number) { const d = new Date(dateStr); d.setDate(d.getDate() + days); return d.toISOString(); }
function daysBetween(fromIso: string, toIso: string) { return Math.ceil((new Date(toIso).getTime() - new Date(fromIso).getTime()) / 86400000); }

function fmtMoney(amount: number, code: string) {
  const cur = CURRENCIES.find(c => c.code === code) || CURRENCIES[0];
  const v = Number(amount) || 0;
  const str = v.toLocaleString(undefined, { minimumFractionDigits: cur.decimals, maximumFractionDigits: cur.decimals });
  return cur.code === 'USD' ? `${cur.symbol}${str}` : `${str}${cur.symbol}`;
}
function toUSD(amount: number, code: string, rates: any) {
  const v = Number(amount) || 0;
  if (code === 'USD') return v;
  const rate = rates[code] || DEFAULT_RATES[code] || 1;
  return v / rate;
}

// ==================== Types ====================
interface Profile {
  id: string;
  businessName: string;
  ownerName: string;
  phone: string;
  password: string;
  payAccount: string;
  payProof: string | null;
  rates: { KHR: number; THB: number };
  qrImage: string | null;
  trialStart: string;
  paidUntil: string | null;
  pendingApproval: boolean;
}
interface InvoiceItem {
  id: number;
  description: string;
  unitPrice: number;
  quantity: number;
  unit: string;
  total: number;
}
interface Payment {
  id: string;
  amount: number;
  date: string;
  note: string;
}
interface Invoice {
  id: string;
  invoiceNo: string;
  date: string;
  custName: string;
  custPhone: string;
  currency: string;
  items: InvoiceItem[];
  payments: Payment[];
  discountType: 'amount' | 'percent';
  discountValue: number;
  status: string;
  total: number;
  subtotal: number;
  discountAmt: number;
  balanceDue: number;
}
interface Expense {
  id: string;
  description: string;
  date: string;
  amount: number;
  currency: string;
}
interface StockLog {
  id: string;
  date: string;
  quantity: number;
  unit: string;
  type: string;
  note: string;
  invoiceNo?: string;
}

// ==================== Shared UI atoms ====================
const Toast = ({ message, type, onClose }: { message: string; type: string; onClose: () => void }) => {
  useEffect(() => { const t = setTimeout(onClose, 3000); return () => clearTimeout(t); }, [onClose]);
  return (
    <div className={`fixed bottom-6 right-4 left-4 sm:left-auto sm:right-8 z-[3000] flex items-center gap-2 px-5 py-3.5 rounded-2xl shadow-2xl border ${type === 'error' ? 'bg-red-50 border-red-200 text-red-700' : 'bg-[#0A1830] text-white border-[#12274A]'}`}>
      {type === 'error' ? <AlertCircle size={14} /> : <CheckCircle size={14} className="text-emerald-400" />}
      <span className="text-[12px] font-bold tracking-tight">{message}</span>
      <button onClick={onClose} className="ml-auto opacity-50 hover:opacity-100 p-1"><X size={12} /></button>
    </div>
  );
};

const FieldLabel = ({ labelKh, labelEn, size = 'normal', children }: { labelKh: string; labelEn?: string; size?: string; children: React.ReactNode }) => (
  <div className={size === 'compact' ? 'space-y-1' : 'space-y-1.5'}>
    <div className={`khmer font-bold text-slate-500 tracking-wide ${size === 'compact' ? 'text-[11px] ml-0.5' : 'text-[12px] ml-1'}`}>
      {labelKh} {labelEn && <span className="text-[#2F5A96] font-semibold text-[10px] uppercase tracking-wider">· {labelEn}</span>}
    </div>
    {children}
  </div>
);

const inputCls = "khmer w-full p-3.5 rounded-xl border border-slate-200 font-semibold text-[16px] leading-relaxed outline-none focus:border-[#2F5A96] focus:ring-2 focus:ring-[#2F5A96]/10 transition-all text-[#0A1830]";
const inputClsCompact = "khmer w-full px-3 py-2.5 rounded-xl border border-slate-200 font-semibold text-[15px] leading-relaxed outline-none focus:border-[#2F5A96] focus:ring-2 focus:ring-[#2F5A96]/10 transition-all text-[#0A1830]";

const BrandMark = ({ size = 36 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ borderRadius: size * 0.22, display: 'block' }}>
    <defs>
      <linearGradient id="navyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0A1830" /><stop offset="100%" stopColor="#12274A" />
      </linearGradient>
    </defs>
    <rect x="0" y="0" width="100" height="100" rx="22" fill="url(#navyGrad)" />
    <rect x="24" y="26" width="52" height="52" rx="6" fill="#FFFFFF" />
    <rect x="30" y="32" width="40" height="9" rx="2.5" fill="#0A1830" />
    <rect x="30" y="48" width="30" height="4" rx="2" fill="#C9D2E0" />
    <rect x="30" y="56" width="26" height="4" rx="2" fill="#C9D2E0" />
    <rect x="30" y="64" width="18" height="4" rx="2" fill="#C9D2E0" />
    <polyline points="54,70 64,60 70,65 84,46" fill="none" stroke="#C9A227" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="84" cy="46" r="6.5" fill="#FFFFFF" /><circle cx="84" cy="46" r="4" fill="#C9A227" />
  </svg>
);

const SecretLogo = ({ size, onSecret }: { size: number; onSecret: () => void }) => {
  const taps = useRef<number[]>([]);
  const handleTap = () => {
    const now = Date.now();
    taps.current = [...taps.current.filter(t => now - t < 3000), now];
    if (taps.current.length >= 5) { taps.current = []; onSecret(); }
  };
  return <button onClick={handleTap} className="shrink-0" aria-label="logo"><BrandMark size={size} /></button>;
};

// ==================== Setup (first run) ====================
function SetupScreen({ onDone, onBack, showToast }: { onDone: (p: Profile) => void; onBack?: () => void; showToast: (m: string, t?: string) => void }) {
  const [f, setF] = useState({ businessName: '', ownerName: '', phoneLocal: '', password: '', confirm: '', payProof: null as string | null });
  const [dragActive, setDragActive] = useState(false);

  const handleFile = (file: File | undefined) => {
    if (!file || !file.type.startsWith('image/')) return showToast('Please select an image file.', 'error');
    if (file.size > 4 * 1024 * 1024) return showToast('Image too large (max 4MB).', 'error');
    const reader = new FileReader();
    reader.onload = () => setF(prev => ({ ...prev, payProof: reader.result as string }));
    reader.readAsDataURL(file);
  };
  const onDrop = (e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setDragActive(false); const file = e.dataTransfer.files && e.dataTransfer.files[0]; if (file) handleFile(file); };

  const submit = async () => {
    if (!f.businessName || !f.ownerName || !f.phoneLocal || !f.password) return showToast('Please fill all required fields.', 'error');
    if (f.password !== f.confirm) return showToast('Passwords do not match.', 'error');
    const profile: Profile = {
      id: `USR-${Date.now()}`,
      businessName: f.businessName, ownerName: f.ownerName, phone: `+855 ${f.phoneLocal}`,
      password: f.password, payAccount: f.ownerName, payProof: f.payProof,
      rates: { ...DEFAULT_RATES }, qrImage: null,
      trialStart: new Date().toISOString(), paidUntil: null, pendingApproval: false
    };
    await saveKey('profile', profile);
    await saveKey('session', { loggedIn: true, phone: profile.phone });
    onDone(profile);
    showToast('Account created.');
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#0A1830] to-[#050B16] flex items-center justify-center p-3 py-6">
      <div className="w-full max-w-md max-h-full overflow-y-auto bg-white rounded-[22px] shadow-2xl p-5 sm:p-6 flex flex-col gap-3">
        {onBack && <button onClick={onBack} className="text-[11px] font-bold text-slate-400 self-start">&larr; Back</button>}
        <div className="text-center">
          <div className="w-12 h-12 mx-auto shadow-lg rounded-xl"><BrandMark size={48} /></div>
          <h1 className="khmer text-[17px] font-bold text-[#0A1830] tracking-tight mt-2 leading-snug">បង្កើតគណនីថ្មី</h1>
          <p className="text-[10px] font-semibold text-slate-400 mt-0.5">Create Your Account</p>
        </div>

        <FieldLabel labelKh="ឈ្មោះអាជីវកម្ម" labelEn="Business Name" size="compact">
          <input value={f.businessName} onChange={e => setF({ ...f, businessName: e.target.value })} className={inputClsCompact} />
        </FieldLabel>

        <div className="grid grid-cols-2 gap-2">
          <FieldLabel labelKh="ឈ្មោះម្ចាស់" labelEn="Your Name" size="compact">
            <input value={f.ownerName} onChange={e => setF({ ...f, ownerName: e.target.value })} className={inputClsCompact} />
          </FieldLabel>
          <FieldLabel labelKh="លេខទូរស័ព្ទ" labelEn="Phone" size="compact">
            <div className="flex items-center gap-1">
              <span className="px-2.5 py-2.5 rounded-lg bg-[#E8EEF8] font-bold text-[#12274A] text-[14px] shrink-0">+855</span>
              <input value={f.phoneLocal} onChange={e => setF({ ...f, phoneLocal: e.target.value })} className={inputClsCompact} />
            </div>
          </FieldLabel>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <FieldLabel labelKh="ពាក្យសម្ងាត់" labelEn="Password" size="compact">
            <input type="password" value={f.password} onChange={e => setF({ ...f, password: e.target.value })} className={inputClsCompact} />
          </FieldLabel>
          <FieldLabel labelKh="បញ្ជាក់ពាក្យសម្ងាត់" labelEn="Confirm" size="compact">
            <input type="password" value={f.confirm} onChange={e => setF({ ...f, confirm: e.target.value })} className={inputClsCompact} />
          </FieldLabel>
        </div>

        <FieldLabel labelKh="គណនីទទួលប្រាក់" labelEn="Payment Account" size="compact">
          <label
            onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragLeave={() => setDragActive(false)}
            onDrop={onDrop}
            className={`flex items-center gap-2.5 py-2.5 px-3 rounded-xl border-2 border-dashed cursor-pointer transition-colors ${dragActive ? 'border-[#2F5A96] bg-[#E8EEF8]/60' : 'border-slate-200 bg-[#F7F9FC] hover:bg-[#E8EEF8]/30 hover:border-[#2F5A96]/40'}`}
          >
            {f.payProof ? (
              <>
                <img src={f.payProof} alt="Proof of payment" className="w-9 h-9 rounded-lg object-contain border border-slate-200 bg-white shrink-0" />
                <span className="khmer text-[12px] font-bold text-[#2F5A96]">ប្តូររូបភាព · Change Photo</span>
              </>
            ) : (
              <>
                <div className="w-8 h-8 rounded-lg bg-[#0A1830] flex items-center justify-center shrink-0"><ImageIcon size={15} className="text-white" /></div>
                <div className="flex flex-col leading-tight">
                  <span className="text-[11.5px] font-black text-slate-500">ផ្ទុកឡើងភស្តុតាងបង់ប្រាក់</span>
                  <span className="text-[9px] font-bold text-slate-400">Upload Proof of Payment</span>
                </div>
              </>
            )}
            <input type="file" accept="image/*" className="hidden" onChange={e => handleFile(e.target.files?.[0])} />
          </label>
        </FieldLabel>

        <button onClick={submit} className="w-full py-2.5 rounded-xl bg-[#0A1830] text-white font-black text-[11px] uppercase tracking-widest shadow-xl active:scale-95 transition-transform hover:bg-[#12274A] mt-0.5">បង្កើតគណនី · Create Account</button>
      </div>
    </div>
  );
}

// ==================== Landing + Login ====================
function LandingScreen({ onChooseLogin, onChooseSignup, onSecretAdmin }: { onChooseLogin: () => void; onChooseSignup: () => void; onSecretAdmin: () => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A1830] to-[#050B16] flex items-center justify-center p-5">
      <div className="w-full max-w-sm bg-white rounded-[28px] shadow-2xl p-8 space-y-7 text-center">
        <div className="w-20 h-20 mx-auto shadow-xl rounded-2xl">
          <SecretLogo size={80} onSecret={onSecretAdmin} />
        </div>
        <div>
          <h1 className="khmer text-xl font-bold text-[#0A1830] tracking-tight">កម្មវិធីគ្រប់គ្រងហិរញ្ញវត្ថុ</h1>
          <p className="text-[11px] font-semibold text-slate-400 mt-1">Financial Management App</p>
        </div>
        <div className="space-y-3">
          <button onClick={onChooseLogin} className="khmer w-full py-3.5 rounded-xl bg-[#0A1830] text-white font-bold text-[15px] shadow-xl active:scale-95 transition-transform hover:bg-[#12274A]">ចូលប្រើប្រាស់ · Log In</button>
          <button onClick={onChooseSignup} className="khmer w-full py-3.5 rounded-xl bg-white border-2 border-[#0A1830] text-[#0A1830] font-bold text-[15px] active:scale-95 transition-transform hover:bg-[#F7F9FC]">ចុះឈ្មោះថ្មី · Sign Up</button>
        </div>
      </div>
    </div>
  );
}

function LoginScreen({ onSuccess, onBack, showToast }: { onSuccess: (p: Profile) => void; onBack: () => void; showToast: (m: string, t?: string) => void }) {
  const [phoneLocal, setPhoneLocal] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);

  const tryLogin = async () => {
    const profile = await loadKey('profile', null);
    if (!profile) return showToast('រកមិនឃើញគណនី — សូមចុះឈ្មោះមុន · No account found — please sign up first.', 'error');
    const enteredPhone = `+855 ${phoneLocal}`;
    if (profile.phone !== enteredPhone || profile.password !== password) {
      return showToast('លេខទូរស័ព្ទ ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ · Invalid phone or password.', 'error');
    }
    await saveKey('session', { loggedIn: true, phone: profile.phone });
    onSuccess(profile);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A1830] to-[#050B16] flex items-center justify-center p-5">
      <div className="w-full max-w-sm bg-white rounded-[28px] shadow-2xl p-8 space-y-5">
        <button onClick={onBack} className="text-[11px] font-bold text-slate-400">&larr; Back</button>
        <div className="text-center">
          <div className="w-16 h-16 mx-auto shadow-lg rounded-2xl"><BrandMark size={64} /></div>
          <h1 className="khmer text-lg font-bold text-[#0A1830] tracking-tight mt-3">ចូលប្រើប្រាស់គណនី</h1>
          <p className="text-[11px] font-semibold text-slate-400">Log In to Your Account</p>
        </div>
        <FieldLabel labelKh="លេខទូរស័ព្ទ" labelEn="Phone">
          <div className="flex items-center gap-2">
            <span className="px-3 py-3.5 rounded-xl bg-[#E8EEF8] font-bold text-[#12274A] text-[15px] shrink-0">+855</span>
            <input value={phoneLocal} onChange={e => setPhoneLocal(e.target.value)} className={inputCls} />
          </div>
        </FieldLabel>
        <FieldLabel labelKh="ពាក្យសម្ងាត់" labelEn="Password">
          <div className="relative">
            <input type={show ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && tryLogin()} className={`${inputCls} pr-11`} />
            <button onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
        </FieldLabel>
        <button onClick={tryLogin} className="khmer w-full py-3.5 rounded-xl bg-[#0A1830] text-white font-bold text-[15px] shadow-xl active:scale-95 transition-transform hover:bg-[#12274A]">ចូល · Log In</button>
      </div>
    </div>
  );
}

// ==================== Trial lock ====================
function TrialLockScreen({ profile, onMarkPending, onSecretAdmin, showToast }: { profile: Profile; onMarkPending: () => void; onSecretAdmin: () => void; showToast: (m: string, t?: string) => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A1830] to-[#050B16] flex items-center justify-center p-5">
      <div className="w-full max-w-sm bg-white rounded-[28px] shadow-2xl p-7 space-y-4 text-center">
        <div className="w-14 h-14 mx-auto rounded-2xl bg-[#0A1830] flex items-center justify-center shadow-lg"><Clock size={26} className="text-[#C9A227]" /></div>
        <div>
          <h1 className="text-lg font-black text-[#0A1830] tracking-tight">រយៈពេលសាកល្បងបានផុតកំណត់</h1>
          <p className="text-[11px] font-bold text-slate-400 mt-1">Your Free Trial Has Ended</p>
        </div>
        <p className="text-[12px] font-bold text-slate-500 leading-relaxed">
          ទិន្នន័យរបស់អ្នកមានសុវត្ថិភាព។ សូមបង់ប្រាក់ <span className="text-[#0A1830] font-black">${SUBSCRIPTION_PRICE_USD}/ខែ</span> ហើយរង់ចាំការអនុម័ត។<br />
          <span className="text-slate-400">Your data is safe. Pay ${SUBSCRIPTION_PRICE_USD}/month, then wait for approval.</span>
        </p>

        {SUBSCRIPTION_QR_IMAGE ? (
          <img src={SUBSCRIPTION_QR_IMAGE} alt="Subscription QR" className="w-40 h-40 mx-auto rounded-xl border-2 border-[#E8EEF8] object-contain" />
        ) : (
          <div className="w-40 h-40 mx-auto rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center text-slate-300"><ImageOff size={22} /></div>
        )}
        <p className="text-[10px] font-bold text-slate-400">{SUBSCRIPTION_PAYEE_NAME}</p>

        {profile.pendingApproval ? (
          <div className="py-2.5 rounded-xl bg-amber-50 border border-amber-100 text-amber-700 font-black text-[11px] uppercase tracking-wide">កំពុងរង់ចាំការអនុម័ត · Pending Approval</div>
        ) : (
          <button onClick={onMarkPending} className="w-full py-3 rounded-xl bg-[#0A1830] text-white font-black text-[11px] uppercase tracking-widest shadow-xl active:scale-95 transition-transform hover:bg-[#12274A]">ខ្ញុំបានបង់ប្រាក់ហើយ · I've Sent Payment</button>
        )}
        <button onClick={onSecretAdmin} className="text-[9px] font-bold text-slate-300 underline">Admin</button>
      </div>
    </div>
  );
}

// ==================== Admin ====================
function AdminPinModal({ onSuccess, onClose, showToast }: { onSuccess: () => void; onClose: () => void; showToast: (m: string, t?: string) => void }) {
  const [pin, setPin] = useState('');
  const submit = () => { if (pin === ADMIN_PIN) onSuccess(); else showToast('PIN incorrect.', 'error'); };
  return (
    <div className="fixed inset-0 z-[5000] flex items-center justify-center p-4 bg-[#050B16]/85 backdrop-blur-sm">
      <div className="bg-white w-full max-w-xs rounded-[24px] shadow-2xl p-6 space-y-4 text-center">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-[#0A1830] flex items-center justify-center"><ShieldCheck size={22} className="text-[#C9A227]" /></div>
        <h3 className="font-black text-[#0A1830] text-sm uppercase tracking-tight">Admin Access</h3>
        <input type="password" inputMode="numeric" value={pin} onChange={e => setPin(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} className={`${inputCls} text-center tracking-[6px]`} autoFocus />
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl font-black text-[11px] text-slate-500 bg-[#F7F9FC] uppercase">Cancel</button>
          <button onClick={submit} className="flex-1 py-2.5 rounded-xl font-black text-[11px] text-white bg-[#0A1830] uppercase">Enter</button>
        </div>
      </div>
    </div>
  );
}

function AdminDashboard({ profile, onExtend, onLock, onClose }: { profile: Profile; onExtend: () => void; onLock: () => void; onClose: () => void }) {
  const expiry = profile.paidUntil || addDays(profile.trialStart, TRIAL_DAYS);
  const daysLeft = daysBetween(new Date().toISOString(), expiry);
  const status = daysLeft > 0 ? (profile.paidUntil ? 'Active (Paid)' : 'Trial') : 'Locked';
  return (
    <div className="fixed inset-0 z-[5000] bg-[#050B16]/90 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[24px] shadow-2xl overflow-hidden">
        <div className="bg-[#0A1830] p-5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#C9A227]/20 flex items-center justify-center"><Users size={18} className="text-[#C9A227]" /></div>
          <div><h3 className="text-white font-black text-sm uppercase tracking-tight">Admin Dashboard</h3><p className="text-[10px] text-slate-400 font-bold">This device's account</p></div>
          <button onClick={onClose} className="ml-auto text-slate-400 hover:text-white"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="p-4 rounded-2xl border border-slate-200 bg-[#F7F9FC] space-y-1.5">
            <div className="flex justify-between text-[12px] font-bold"><span className="text-slate-400">Business</span><span className="text-[#0A1830] font-black">{profile.businessName}</span></div>
            <div className="flex justify-between text-[12px] font-bold"><span className="text-slate-400">Owner</span><span>{profile.ownerName}</span></div>
            <div className="flex justify-between text-[12px] font-bold"><span className="text-slate-400">Phone</span><span>{profile.phone}</span></div>
            <div className="flex justify-between text-[12px] font-bold"><span className="text-slate-400">Status</span><span className={`font-black ${status === 'Locked' ? 'text-rose-500' : 'text-emerald-600'}`}>{status}</span></div>
            <div className="flex justify-between text-[12px] font-bold"><span className="text-slate-400">Days Left</span><span className="font-black">{daysLeft}</span></div>
            {profile.pendingApproval && <div className="flex justify-between text-[12px] font-black text-amber-600"><span>Awaiting Approval</span><Clock size={14} /></div>}
          </div>
          <div className="flex gap-2">
            <button onClick={onExtend} className="flex-1 py-3 rounded-xl font-black text-[11px] text-white bg-emerald-600 hover:bg-emerald-700 uppercase flex items-center justify-center gap-1.5"><Check size={14} /> Approve / Extend 30d</button>
            <button onClick={onLock} className="flex-1 py-3 rounded-xl font-black text-[11px] text-white bg-rose-600 hover:bg-rose-700 uppercase flex items-center justify-center gap-1.5"><Ban size={14} /> Lock Now</button>
          </div>
          <p className="text-[9px] font-bold text-slate-400 leading-relaxed">Note: this panel only manages the account on this device. Approving vendors on other phones requires connecting this app to a real backend.</p>
        </div>
      </div>
    </div>
  );
}

// ==================== Main App ====================
export default function App() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [authView, setAuthView] = useState<'landing' | 'login' | 'signup'>('landing');
  const [activePage, setActivePage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'edit' | 'split' | 'preview'>('split');
  const [showQR, setShowQR] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: string } | null>(null);
  const showToast = (message: string, type = 'success') => setToast({ message, type });

  const [adminPinOpen, setAdminPinOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [stockLogs, setStockLogs] = useState<StockLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [settleModal, setSettleModal] = useState<{ open: boolean; invoice: Invoice | null; amount: number | string; date: string; note: string }>({ open: false, invoice: null, amount: 0, date: new Date().toISOString().split('T')[0], note: 'Cash' });
  const [picker, setPicker] = useState({ description: '', quantity: 1 as number | string, unitPrice: 0 as number | string, unit: 'PCS' });
  const [settingsForm, setSettingsForm] = useState<Profile | null>(null);
  const [expenseForm, setExpenseForm] = useState({ description: '', date: new Date().toISOString().split('T')[0], amount: '' as number | string, currency: 'USD' });
  const [stockForm, setStockForm] = useState({ date: new Date().toISOString().split('T')[0], quantity: '' as number | string, description: '', direction: 'IN' as 'IN' | 'OUT' });

  const [form, setForm] = useState<Invoice & { invoiceNo: string }>({
    invoiceNo: '1', date: new Date().toISOString().split('T')[0], custName: '', custPhone: '',
    currency: 'USD', items: [], payments: [], discountType: 'amount', discountValue: 0, status: 'Draft',
    id: '', total: 0, subtotal: 0, discountAmt: 0, balanceDue: 0
  });

  useEffect(() => {
    (async () => {
      const p = await loadKey('profile', null);
      const inv = await loadKey('invoices', []);
      const exp = await loadKey('expenses', []);
      const stock = await loadKey('stock-logs', []);
      const session = await loadKey('session', { loggedIn: false });
      setProfile(p); setInvoices(inv); setExpenses(exp); setStockLogs(stock);
      if (p && session.loggedIn) setUnlocked(true);
      setLoaded(true);
    })();
  }, []);
  useEffect(() => { if (loaded) saveKey('invoices', invoices); }, [invoices, loaded]);
  useEffect(() => { if (loaded) saveKey('expenses', expenses); }, [expenses, loaded]);
  useEffect(() => { if (loaded) saveKey('stock-logs', stockLogs); }, [stockLogs, loaded]);

  useEffect(() => {
    if (!currentId) {
      const nums = invoices.map(i => parseInt(i.invoiceNo)).filter(n => !isNaN(n));
      const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
      setForm(prev => ({ ...prev, invoiceNo: next.toString() }));
    }
  }, [invoices.length, currentId]);

  const rates = profile?.rates || DEFAULT_RATES;
  const subtotal = useMemo(() => form.items.reduce((a, i) => a + (Number(i.total) || 0), 0), [form.items]);
  const discountAmt = useMemo(() => form.discountType === 'percent' ? subtotal * (Number(form.discountValue) || 0) / 100 : (Number(form.discountValue) || 0), [form.discountType, form.discountValue, subtotal]);
  const total = Math.max(0, subtotal - discountAmt);
  const totalPaidInForm = useMemo(() => (form.payments || []).reduce((a, p) => a + Number(p.amount), 0), [form.payments]);
  const balanceDue = total - totalPaidInForm;

  const dashboardTotals = useMemo(() => {
    const incomeUSD = invoices.reduce((a, i) => a + toUSD(i.total, i.currency || 'USD', rates), 0);
    const expenseUSD = expenses.reduce((a, e) => a + toUSD(e.amount, e.currency || 'USD', rates), 0);
    return { incomeUSD, expenseUSD, netUSD: incomeUSD - expenseUSD };
  }, [invoices, expenses, rates]);

  const stockSummary = useMemo(() => {
    const collected = invoices.reduce((a, i) => a + (i.payments || []).reduce((s, p) => s + Number(p.amount), 0), 0);
    const balancePcs = stockLogs.reduce((a, l) => a + (l.unit === 'PCS' ? Number(l.quantity) || 0 : 0), 0);
    const totalIn = stockLogs.reduce((a, l) => a + (Number(l.quantity) > 0 ? Number(l.quantity) : 0), 0);
    const totalOut = stockLogs.reduce((a, l) => a + (Number(l.quantity) < 0 ? Math.abs(Number(l.quantity)) : 0), 0);
    return { collected, balancePcs, totalIn, totalOut };
  }, [stockLogs, invoices]);

  const qrPreviewUrl = profile?.qrImage || null;

  const saveDraft = () => {
    if (!form.custName) return showToast('Customer name required.', 'error');
    const id = currentId || `INV-${Date.now()}`;
    const record: Invoice = { ...form, id, total, subtotal, discountAmt, balanceDue };
    setInvoices(prev => { const exists = prev.find(i => i.id === id); return exists ? prev.map(i => i.id === id ? record : i) : [...prev, record]; });
    setCurrentId(id);
    showToast(form.status === 'Posted' ? 'Updated.' : 'Draft saved.');
  };

  const postInvoice = () => {
    if (form.items.length === 0) return showToast('Add at least one item.', 'error');
    if (!form.custName) return showToast('Customer name required.', 'error');
    const id = currentId || `INV-${Date.now()}`;
    const record: Invoice = { ...form, id, total, subtotal, discountAmt, balanceDue, status: 'Posted' };
    const filteredStock = stockLogs.filter(l => !(l.invoiceNo === form.invoiceNo && l.type === 'Sale'));
    const newStock: StockLog[] = form.items.filter(it => it.unit === 'PCS').map(it => ({ id: `LOG-${Date.now()}-${Math.random()}`, quantity: -it.quantity, unit: 'PCS', type: 'Sale', invoiceNo: form.invoiceNo, note: `#${form.invoiceNo}: ${it.description}`, date: form.date }));
    setStockLogs([...filteredStock, ...newStock]);
    setInvoices(prev => { const exists = prev.find(i => i.id === id); return exists ? prev.map(i => i.id === id ? record : i) : [...prev, record]; });
    setCurrentId(id);
    setForm(prev => ({ ...prev, status: 'Posted' }));
    showToast('Invoice posted.');
  };

  const startNewInvoice = () => {
    setCurrentId(null);
    setForm({ invoiceNo: '', date: new Date().toISOString().split('T')[0], custName: '', custPhone: '', currency: 'USD', items: [], payments: [], discountType: 'amount', discountValue: 0, status: 'Draft', id: '', total: 0, subtotal: 0, discountAmt: 0, balanceDue: 0 });
    setActivePage('invoice');
  };
  const startEditInvoice = (inv: Invoice) => { setForm({ ...inv, discountType: inv.discountType || 'amount', discountValue: inv.discountValue || 0, payments: inv.payments || [] }); setCurrentId(inv.id); setActivePage('invoice'); setSidebarOpen(false); };
  const deleteInvoice = (inv: Invoice) => { if (!confirm(`Delete #${inv.invoiceNo}?`)) return; setInvoices(prev => prev.filter(i => i.id !== inv.id)); setStockLogs(prev => prev.filter(l => !(l.invoiceNo === inv.invoiceNo && l.type === 'Sale'))); showToast('Deleted.'); };

  const commitPayment = () => {
    const amt = Number(settleModal.amount);
    if (amt <= 0) return showToast('Enter a valid amount.', 'error');
    if (settleModal.invoice) {
      const inv = settleModal.invoice;
      const updated = [...(inv.payments || []), { id: `PAY-${Date.now()}`, amount: amt, date: settleModal.date, note: settleModal.note || 'Payment' }];
      const paidSum = updated.reduce((a, p) => a + Number(p.amount), 0);
      setInvoices(prev => prev.map(i => i.id === inv.id ? { ...i, payments: updated, balanceDue: Number(i.total) - paidSum } : i));
      showToast('Payment recorded.');
    } else {
      setForm(prev => ({ ...prev, payments: [...(prev.payments || []), { id: `PAY-${Date.now()}`, amount: amt, date: settleModal.date, note: settleModal.note || 'Payment' }] }));
      showToast('Added to draft.');
    }
    setSettleModal({ open: false, invoice: null, amount: 0, date: new Date().toISOString().split('T')[0], note: 'Cash' });
  };

  const addExpense = () => {
    if (!expenseForm.description || !expenseForm.amount) return showToast('Description and amount required.', 'error');
    setExpenses(prev => [...prev, { id: `EXP-${Date.now()}`, ...expenseForm, amount: Number(expenseForm.amount) } as Expense]);
    setExpenseForm({ description: '', date: new Date().toISOString().split('T')[0], amount: '', currency: 'USD' });
    showToast('Expense recorded.');
  };
  const deleteExpense = (id: string) => setExpenses(prev => prev.filter(e => e.id !== id));

  const addStockEntry = () => {
    if (!stockForm.description || !stockForm.quantity) return showToast('Description and quantity required.', 'error');
    const qty = Math.abs(Number(stockForm.quantity)) * (stockForm.direction === 'OUT' ? -1 : 1);
    setStockLogs(prev => [...prev, { id: `LOG-${Date.now()}`, date: stockForm.date, quantity: qty, unit: 'PCS', type: stockForm.direction === 'OUT' ? 'Stock Out' : 'Stock In', note: stockForm.description }]);
    setStockForm({ date: new Date().toISOString().split('T')[0], quantity: '', description: '', direction: 'IN' });
    showToast('Stock updated.');
  };
  const deleteStockEntry = (id: string) => setStockLogs(prev => prev.filter(l => l.id !== id));

  const saveSettings = async () => {
    if (!settingsForm || !profile) return;
    const updated = { ...profile, ...settingsForm };
    setProfile(updated); await saveKey('profile', updated);
    showToast('Settings saved.');
  };
  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    if (file.size > 4 * 1024 * 1024) return showToast('Image too large (max 4MB).', 'error');
    const reader = new FileReader();
    reader.onload = () => setSettingsForm(prev => prev ? { ...prev, qrImage: reader.result as string } : prev);
    reader.readAsDataURL(file);
  };

  const trialExpiryIso = profile ? (profile.paidUntil || addDays(profile.trialStart || new Date().toISOString(), TRIAL_DAYS)) : null;
  const daysLeft = profile && trialExpiryIso ? daysBetween(new Date().toISOString(), trialExpiryIso) : 0;
  const isTrialLocked = profile ? daysLeft <= 0 : false;

  const markPendingApproval = async () => {
    if (!profile) return;
    const updated = { ...profile, pendingApproval: true };
    setProfile(updated); await saveKey('profile', updated);
    showToast('Marked as pending — waiting for admin approval.');
  };
  const adminExtend = async () => {
    if (!profile) return;
    const updated = { ...profile, paidUntil: addDays(new Date().toISOString(), TRIAL_DAYS), pendingApproval: false };
    setProfile(updated); await saveKey('profile', updated);
    showToast('Approved for 30 more days.');
  };
  const adminLock = async () => {
    if (!profile) return;
    const updated = { ...profile, paidUntil: new Date(Date.now() - 86400000).toISOString() };
    setProfile(updated); await saveKey('profile', updated);
    showToast('Account locked.');
  };
  const handleLogout = async () => {
    await saveKey('session', { loggedIn: false });
    setUnlocked(false);
    setAuthView('landing');
  };

  if (!loaded) return <div className="min-h-screen bg-[#F7F9FC] flex items-center justify-center text-slate-400 font-bold text-sm">Loading…</div>;

  if (!unlocked) {
    if (authView === 'signup') {
      return <SetupScreen onBack={() => setAuthView('landing')} onDone={(p) => { setProfile(p); setUnlocked(true); }} showToast={showToast} />;
    }
    if (authView === 'login') {
      return <LoginScreen onBack={() => setAuthView('landing')} onSuccess={(p) => { setProfile(p); setUnlocked(true); }} showToast={showToast} />;
    }
    return (
      <>
        <LandingScreen onChooseLogin={() => setAuthView('login')} onChooseSignup={() => setAuthView('signup')} onSecretAdmin={() => setAdminPinOpen(true)} />
        {adminPinOpen && <AdminPinModal onSuccess={async () => { setAdminPinOpen(false); const p = await loadKey('profile', null); if (p) { setProfile(p); setAdminOpen(true); } else showToast('No account exists yet on this device.', 'error'); }} onClose={() => setAdminPinOpen(false)} showToast={showToast} />}
        {adminOpen && profile && <AdminDashboard profile={profile} onExtend={adminExtend} onLock={adminLock} onClose={() => setAdminOpen(false)} />}
      </>
    );
  }

  if (isTrialLocked && profile) {
    return (
      <>
        <TrialLockScreen profile={profile} onMarkPending={markPendingApproval} onSecretAdmin={() => setAdminPinOpen(true)} showToast={showToast} />
        {adminPinOpen && <AdminPinModal onSuccess={() => { setAdminPinOpen(false); setAdminOpen(true); }} onClose={() => setAdminPinOpen(false)} showToast={showToast} />}
        {adminOpen && <AdminDashboard profile={profile} onExtend={adminExtend} onLock={adminLock} onClose={() => setAdminOpen(false)} />}
      </>
    );
  }

  if (!profile) return null;

  const renderInvoiceView = () => (
    <div className="invoice-view flex flex-col bg-white text-[#0A1830] shadow-xl overflow-hidden w-full max-w-[620px] p-6 sm:p-10 rounded-2xl border border-slate-100">
      <div className="flex justify-between items-start border-b-2 border-[#0A1830] pb-5 mb-5">
        <div className="flex items-start gap-3">
          <div className="shrink-0 mt-0.5"><BrandMark size={44} /></div>
          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tighter leading-none">វិក្កយបត្រ <span className="text-[#2F5A96] text-[14px] font-bold">INVOICE</span></h1>
            <div className="h-[3px] w-10 bg-[#C9A227] rounded-full mt-2 mb-1.5"></div>
            <p className="text-[14px] font-black text-[#0A1830] uppercase tracking-tight">{profile.businessName}</p>
            <div className="flex items-center gap-2 text-[10px] font-semibold text-slate-400 mt-1"><Phone size={10} className="text-slate-300" /> <span>{profile.phone}</span></div>
          </div>
        </div>
        <div className="text-right">
          <p className="text-lg font-black font-mono tracking-tighter text-[#2F5A96]">#{String(form.invoiceNo).padStart(6, '0')}</p>
          <p className="text-[10px] font-semibold text-slate-400 italic">{new Date(form.date).toLocaleDateString()}</p>
        </div>
      </div>

      <div className="mb-6 space-y-1">
        <p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">អតិថិជន · Recipient</p>
        <h2 className="text-xl font-black tracking-tight uppercase">{form.custName || '---'}</h2>
        {form.custPhone && <p className="text-[11px] font-bold text-slate-400">{form.custPhone}</p>}
      </div>

      <div className="flex-grow mb-6 overflow-x-auto">
        <table className="w-full min-w-[300px]">
          <thead className="bg-[#F7F9FC] text-[9px] font-black text-slate-400 uppercase tracking-widest">
            <tr><th className="py-3 px-3 text-left">បរិយាយ · Item</th><th className="py-3 px-3 text-center">ថ្លៃ · Price</th><th className="py-3 px-3 text-center">ចំនួន · Qty</th><th className="py-3 px-3 text-right">សរុប · Total</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {form.items.length > 0 ? form.items.map(i => (
              <tr key={i.id}>
                <td className="py-3 px-3 font-bold text-[13px] uppercase">{i.description}</td>
                <td className="py-3 px-3 text-center text-[10px] text-slate-400 font-bold">{fmtMoney(i.unitPrice, form.currency)}</td>
                <td className="py-3 px-3 text-center text-[13px] font-black">{i.quantity} {i.unit}</td>
                <td className="py-3 px-3 text-right font-black text-[13px]">{fmtMoney(i.total, form.currency)}</td>
              </tr>
            )) : <tr><td colSpan={4} className="py-10 text-center text-[11px] text-slate-300 font-bold uppercase italic">No items</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="flex flex-col items-end pt-5 border-t border-slate-200">
        <div className="w-full sm:w-60 space-y-1.5">
          <div className="flex justify-between text-[11px] font-bold text-slate-400 uppercase"><span>សរុបរង · Subtotal</span><span>{fmtMoney(subtotal, form.currency)}</span></div>
          {discountAmt > 0 && <div className="flex justify-between text-[11px] font-bold text-[#C9A227] uppercase"><span>បញ្ចុះតម្លៃ · Discount</span><span>-{fmtMoney(discountAmt, form.currency)}</span></div>}
          <div className="flex justify-between text-[#2F5A96] text-[11px] font-black uppercase"><span>បានបង់ · Paid</span><span>{fmtMoney(totalPaidInForm, form.currency)}</span></div>
          <div className="pt-3 border-t-2 border-[#0A1830] mt-1.5">
            <div className="flex justify-between items-center"><span className="text-[12px] font-black uppercase">ត្រូវទូទាត់ · Balance</span><span className="text-xl font-black tracking-tighter">{fmtMoney(balanceDue, form.currency)}</span></div>
          </div>
        </div>
      </div>

      <button onClick={() => setShowQR(true)} className="mt-6 w-full py-3.5 rounded-xl bg-[#0A1830] text-white font-black text-[11px] uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform hover:bg-[#12274A]">
        <QrCode size={16} /> បង់ប្រាក់ដោយ QR · Show Payment QR
      </button>
      <div className="mt-7 pt-4 border-t border-slate-100 flex justify-between items-center text-[8px] font-bold text-slate-300 uppercase tracking-widest">
        <span>Serial #{form.invoiceNo}</span><span>Digital Record</span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      {profile.pendingApproval && daysLeft > 0 && (
        <div className="no-print bg-amber-500 text-white px-4 py-2 text-center text-[11px] font-bold">កំពុងរង់ចាំការអនុម័ត · Your subscription payment is pending admin approval</div>
      )}
      <div className="flex flex-col lg:flex-row flex-1 antialiased bg-[#F7F9FC] text-[#0A1830]">
        {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
        {adminPinOpen && <AdminPinModal onSuccess={() => { setAdminPinOpen(false); setAdminOpen(true); }} onClose={() => setAdminPinOpen(false)} showToast={showToast} />}
        {adminOpen && <AdminDashboard profile={profile} onExtend={adminExtend} onLock={adminLock} onClose={() => setAdminOpen(false)} />}

        {showQR && (
          <div className="fixed inset-0 z-[4000] flex items-center justify-center p-4 bg-[#050B16]/80 backdrop-blur-sm">
            <div className="bg-white w-full max-w-xs rounded-[28px] shadow-2xl p-7 text-center space-y-4">
              <h3 className="font-black text-[#0A1830] uppercase tracking-tight text-sm">ស្កេនដើម្បីបង់ប្រាក់ · Scan to Pay</h3>
              {qrPreviewUrl ? (
                <img src={qrPreviewUrl} alt="Payment QR" className="mx-auto rounded-xl border-2 border-[#E8EEF8] w-52 h-52 object-contain" />
              ) : (
                <div className="w-52 h-52 mx-auto rounded-xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-300 gap-2">
                  <ImageOff size={28} /><span className="text-[10px] font-bold uppercase px-4 text-center">No QR uploaded — add one in Settings</span>
                </div>
              )}
              <div className="text-[14px] font-black">{fmtMoney(balanceDue, form.currency)}</div>
              <p className="text-[10px] text-slate-400 font-bold">{profile.payAccount}</p>
              <button onClick={() => setShowQR(false)} className="w-full py-2.5 rounded-xl bg-[#F7F9FC] text-slate-600 font-black text-[11px] uppercase">Close</button>
            </div>
          </div>
        )}

        <aside className={`no-print fixed inset-y-0 left-0 z-40 transition-all duration-300 shadow-2xl border-r bg-white border-slate-100 lg:translate-x-0 ${sidebarOpen ? 'translate-x-0 w-64' : '-translate-x-full lg:translate-x-0 lg:w-16'}`}>
          <div className="h-14 lg:h-16 border-b border-slate-100 flex items-center px-4 gap-3">
            <SecretLogo size={36} onSecret={() => setAdminPinOpen(true)} />
            <div className={`flex flex-col ${!sidebarOpen && 'lg:hidden'}`}>
              <span className="font-black text-[11px] tracking-tighter uppercase truncate max-w-[140px] text-[#0A1830]">{profile.businessName}</span>
              <span className="text-[8px] font-black text-[#C9A227] uppercase">v2.0</span>
            </div>
          </div>
          <nav className="p-2 space-y-1.5 mt-4">
            {[
              { id: 'dashboard', icon: LayoutDashboard, label: 'ផ្ទាំងគ្រប់គ្រង · Dashboard' },
              { id: 'invoice', icon: Edit3, label: 'ចំណូល · Income' },
              { id: 'expenses', icon: Receipt, label: 'ចំណាយ · Expenses' },
              { id: 'ledger', icon: History, label: 'កំណត់ត្រា · Ledger' },
              { id: 'inventory', icon: Box, label: 'ឃ្លាំង · Warehouse' },
              { id: 'settings', icon: Settings, label: 'ការកំណត់ · Settings' }
            ].map(btn => (
              <button key={btn.id} onClick={() => { setActivePage(btn.id); if (btn.id === 'settings') setSettingsForm({ ...profile }); if (window.innerWidth < 1024) setSidebarOpen(false); }} className={`w-full flex items-center gap-4 px-3 py-3 rounded-xl transition-all ${activePage === btn.id ? 'bg-[#0A1830] text-white shadow-lg' : 'text-slate-400 hover:text-[#0A1830] hover:bg-[#F7F9FC]'}`}>
                <btn.icon size={18} />
                <span className={`font-bold text-[11px] leading-tight text-left ${!sidebarOpen && 'lg:hidden'}`}>{btn.label}</span>
              </button>
            ))}
          </nav>
        </aside>

        {sidebarOpen && <div onClick={() => setSidebarOpen(false)} className="fixed inset-0 bg-[#050B16]/40 backdrop-blur-sm z-30 lg:hidden" />}

        <main className={`flex-1 transition-all duration-300 flex flex-col ${sidebarOpen ? 'lg:ml-64' : 'lg:ml-16'}`}>
          <header className="h-14 lg:h-16 border-b border-slate-100 px-4 lg:px-6 flex items-center justify-between no-print sticky top-0 z-20 bg-white/95 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="p-2 lg:hidden text-slate-500"><Menu size={18} /></button>
              {activePage === 'invoice' && (
                <div className="flex p-1 rounded-xl border border-slate-200 bg-[#F7F9FC]">
                  {(['edit', 'split', 'preview'] as const).map(m => (
                    <button key={m} onClick={() => setViewMode(m)} className={`px-3.5 py-1.5 rounded-lg text-[10px] font-black transition-all ${viewMode === m ? 'bg-white text-[#0A1830] shadow-sm' : 'text-slate-400'}`}>{m.toUpperCase()}</button>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              {activePage === 'invoice' && (
                <>
                  <button onClick={startNewInvoice} className="hidden sm:flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-black text-[10px] border border-slate-200 bg-white text-slate-500"><Plus size={14} /> NEW</button>
                  <button onClick={saveDraft} className="hidden sm:flex items-center gap-2 px-4 py-2.5 rounded-xl font-black text-[10px] border border-slate-200 bg-white text-[#0A1830]"><Save size={14} /> {currentId ? 'SYNC' : 'DRAFT'}</button>
                  <button onClick={postInvoice} className="px-4 sm:px-6 py-2.5 rounded-xl font-black text-[10px] shadow-lg active:scale-95 transition-all flex items-center gap-2 bg-[#0A1830] text-white hover:bg-[#12274A]">
                    {form.status === 'Posted' ? <CheckCircle size={14} /> : <ArrowRight size={14} />}
                    <span className="hidden sm:inline uppercase">{form.status === 'Posted' ? 'Posted' : 'Post'}</span>
                  </button>
                </>
              )}
            </div>
          </header>

          <div className="flex-1 overflow-y-auto">
            {activePage === 'dashboard' && (
              <div className="p-3 sm:p-5 w-full max-w-[1200px] mx-auto">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
                  <div className="bg-white border border-slate-200 shadow-sm p-4 rounded-xl relative overflow-hidden">
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">ចំណូលសរុប · Total Income</div>
                    <div className="text-2xl font-black tracking-tighter text-emerald-600">{fmtMoney(dashboardTotals.incomeUSD, 'USD')}</div>
                    <TrendingUp size={70} className="absolute -right-3 -bottom-3 opacity-[0.06]" />
                  </div>
                  <div className="bg-white border border-slate-200 shadow-sm p-4 rounded-xl relative overflow-hidden">
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">ចំណាយសរុប · Total Expenses</div>
                    <div className="text-2xl font-black tracking-tighter text-rose-500">{fmtMoney(dashboardTotals.expenseUSD, 'USD')}</div>
                    <TrendingDown size={70} className="absolute -right-3 -bottom-3 opacity-[0.06]" />
                  </div>
                  <div className="bg-[#0A1830] p-4 rounded-xl relative overflow-hidden">
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">សមតុល្យ · Net Balance</div>
                    <div className={`text-2xl font-black tracking-tighter ${dashboardTotals.netUSD >= 0 ? 'text-[#C9A227]' : 'text-rose-400'}`}>{fmtMoney(dashboardTotals.netUSD, 'USD')}</div>
                    <Wallet size={70} className="absolute -right-3 -bottom-3 opacity-[0.08] text-white" />
                  </div>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-4">
                  <h3 className="text-[12px] font-black text-slate-400 uppercase tracking-widest mb-4">សកម្មភាពថ្មីៗ · Recent Activity</h3>
                  <div className="space-y-2">
                    {[...invoices].slice(-3).reverse().map(i => (
                      <div key={i.id} className="flex justify-between items-center p-3 rounded-xl bg-[#F7F9FC] text-[12px] font-bold">
                        <span className="uppercase">{i.custName}</span><span className="text-emerald-600 font-black">+{fmtMoney(i.total, i.currency)}</span>
                      </div>
                    ))}
                    {[...expenses].slice(-3).reverse().map(e => (
                      <div key={e.id} className="flex justify-between items-center p-3 rounded-xl bg-[#F7F9FC] text-[12px] font-bold">
                        <span className="uppercase">{e.description}</span><span className="text-rose-500 font-black">-{fmtMoney(e.amount, e.currency)}</span>
                      </div>
                    ))}
                    {invoices.length === 0 && expenses.length === 0 && <div className="text-center py-6 text-[11px] text-slate-300 font-bold uppercase italic">No activity yet</div>}
                  </div>
                </div>
              </div>
            )}

            {activePage === 'invoice' && (
              <div className="flex flex-col lg:flex-row h-full">
                {(viewMode === 'edit' || viewMode === 'split') && (
                  <div className={`p-5 lg:p-9 border-r border-slate-100 bg-white flex-shrink-0 overflow-y-auto ${viewMode === 'split' ? 'lg:w-[480px]' : 'w-full'}`}>
                    <div className="w-full max-w-lg mx-auto space-y-5 pb-16">
                      <section className="space-y-4">
                        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><User size={14} className="text-[#2F5A96]" /> អត្តសញ្ញាណ · Identity</div>
                          <span className={`px-2.5 py-1 rounded-lg text-[8px] font-black border ${form.status === 'Posted' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-[#E8EEF8] text-[#2F5A96] border-[#d5e0f2]'}`}>{form.status.toUpperCase()}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <FieldLabel labelKh="លេខរៀង" labelEn="Serial"><input value={form.invoiceNo} onChange={e => setForm({ ...form, invoiceNo: e.target.value })} className={`${inputCls} font-mono bg-[#F7F9FC]`} /></FieldLabel>
                          <FieldLabel labelKh="កាលបរិច្ឆេទ" labelEn="Date"><input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className={`${inputCls} bg-[#F7F9FC]`} /></FieldLabel>
                        </div>
                        <FieldLabel labelKh="រូបិយប័ណ្ណ" labelEn="Currency">
                          <select value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value })} className={`${inputCls} bg-[#F7F9FC]`}>
                            {CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.symbol} {c.code}</option>)}
                          </select>
                        </FieldLabel>
                        <FieldLabel labelKh="ឈ្មោះអតិថិជន" labelEn="Customer Name"><input value={form.custName} onChange={e => setForm({ ...form, custName: e.target.value })} className="w-full border-b-2 border-slate-200 py-2.5 text-lg font-black outline-none bg-transparent focus:border-[#2F5A96]" /></FieldLabel>
                        <FieldLabel labelKh="លេខទូរស័ព្ទ" labelEn="Customer Phone"><input value={form.custPhone} onChange={e => setForm({ ...form, custPhone: e.target.value })} className={`${inputCls} bg-[#F7F9FC]`} /></FieldLabel>
                      </section>

                      <section className="space-y-4 pt-4 border-t border-slate-100">
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><ShoppingBag size={14} className="text-[#2F5A96]" /> ទំនិញ · Products</div>
                        <div className="p-5 rounded-2xl space-y-4 border border-slate-100 bg-[#F7F9FC]">
                          <FieldLabel labelKh="បរិយាយ" labelEn="Item"><input value={picker.description} onChange={e => setPicker({ ...picker, description: e.target.value })} className={`${inputCls} bg-white`} /></FieldLabel>
                          <div className="grid grid-cols-3 gap-3">
                            <FieldLabel labelKh="ថ្លៃ" labelEn="Price"><input type="number" value={picker.unitPrice} onChange={e => setPicker({ ...picker, unitPrice: e.target.value })} className={`${inputCls} bg-white`} /></FieldLabel>
                            <FieldLabel labelKh="ចំនួន" labelEn="Qty"><input type="number" value={picker.quantity} onChange={e => setPicker({ ...picker, quantity: e.target.value })} className={`${inputCls} bg-white text-[#2F5A96]`} /></FieldLabel>
                            <FieldLabel labelKh="ឯកតា" labelEn="Unit">
                              <select value={picker.unit} onChange={e => setPicker({ ...picker, unit: e.target.value })} className={`${inputCls} bg-white`}>
                                {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                              </select>
                            </FieldLabel>
                          </div>
                          <button onClick={() => { if (!picker.description || !picker.quantity) return; setForm(prev => ({ ...prev, items: [...prev.items, { ...picker, id: Date.now(), total: Number(picker.unitPrice) * Number(picker.quantity) }] })); setPicker({ description: '', quantity: 1, unitPrice: 0, unit: 'PCS' }); }} className="w-full py-3 rounded-xl font-black text-[11px] flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform bg-[#0A1830] text-white uppercase tracking-widest hover:bg-[#12274A]">បន្ថែម · Append Row <Plus size={16} /></button>
                        </div>
                        <div className="space-y-2">
                          {form.items.map(i => (
                            <div key={i.id} className="flex justify-between items-center p-3.5 border border-slate-200 rounded-xl bg-white">
                              <div className="flex items-center gap-2.5">
                                <div className="w-8 h-8 rounded-lg bg-[#E8EEF8] flex items-center justify-center text-[#2F5A96] shrink-0">{i.unit === 'SHIPPING' ? <Truck size={15} /> : <ShoppingBag size={15} />}</div>
                                <div><div className="font-black text-[12px] uppercase">{i.description}</div><div className="text-[10px] font-bold text-slate-400">{i.quantity} {i.unit} × {fmtMoney(i.unitPrice, form.currency)}</div></div>
                              </div>
                              <div className="flex items-center gap-3"><span className="font-black text-[13px]">{fmtMoney(i.total, form.currency)}</span><button onClick={() => setForm(prev => ({ ...prev, items: prev.items.filter(it => it.id !== i.id) }))} className="text-slate-300 hover:text-red-500 p-1.5"><Trash2 size={14} /></button></div>
                            </div>
                          ))}
                        </div>
                      </section>

                      <section className="space-y-4 pt-4 border-t border-slate-100">
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><Percent size={14} className="text-[#C9A227]" /> បញ្ចុះតម្លៃ · Discount</div>
                        <div className="flex gap-3 items-end">
                          <div className="flex-1"><FieldLabel labelKh="តម្លៃ" labelEn="Value"><input type="number" value={form.discountValue} onChange={e => setForm({ ...form, discountValue: Number(e.target.value) })} className={`${inputCls} focus:border-[#C9A227]`} /></FieldLabel></div>
                          <div className="flex rounded-xl border border-slate-200 overflow-hidden">
                            <button onClick={() => setForm({ ...form, discountType: 'amount' })} className={`px-3.5 py-3 font-black text-[11px] ${form.discountType === 'amount' ? 'bg-[#0A1830] text-white' : 'bg-white text-slate-400'}`}>$</button>
                            <button onClick={() => setForm({ ...form, discountType: 'percent' })} className={`px-3.5 py-3 font-black text-[11px] ${form.discountType === 'percent' ? 'bg-[#0A1830] text-white' : 'bg-white text-slate-400'}`}>%</button>
                          </div>
                        </div>
                        {discountAmt > 0 && <div className="text-[11px] font-bold text-[#C9A227]">-{fmtMoney(discountAmt, form.currency)}</div>}
                      </section>

                      <section className="space-y-4 pt-4 border-t border-slate-100">
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><CreditCard size={14} className="text-[#2F5A96]" /> កំណត់ត្រា · Ledger</div>
                        <div className="p-5 rounded-3xl space-y-4 border border-slate-100 bg-white shadow-sm">
                          <div className="space-y-2">
                            {(form.payments || []).length > 0 ? form.payments.map((p, idx) => (
                              <div key={idx} className="flex justify-between items-center text-[11px] font-black border-b border-dashed border-slate-100 pb-2 last:border-0">
                                <div className="flex flex-col"><span className="text-slate-400 text-[9px] uppercase">{p.date}</span><span className="text-slate-300 text-[9px] italic">{p.note}</span></div>
                                <div className="flex items-center gap-3 text-emerald-600"><span className="text-[13px]">{fmtMoney(p.amount, form.currency)}</span><button onClick={() => setForm(prev => ({ ...prev, payments: prev.payments.filter((_, i) => i !== idx) }))} className="text-slate-300 hover:text-red-500"><X size={12} /></button></div>
                              </div>
                            )) : <div className="text-center py-4 text-[10px] text-slate-300 font-bold uppercase italic">No payments yet</div>}
                          </div>
                          <button onClick={() => setSettleModal({ open: true, invoice: null, amount: 0, date: new Date().toISOString().split('T')[0], note: 'Cash' })} className="w-full py-2.5 rounded-xl border border-[#E8EEF8] text-[#2F5A96] font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-1.5"><DollarSign size={12} /> បន្ថែមការទូទាត់ · Add Payment</button>
                          <div className="pt-4 border-t border-slate-100 space-y-1 text-right">
                            <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase"><span>Subtotal</span><span>{fmtMoney(subtotal, form.currency)}</span></div>
                            {discountAmt > 0 && <div className="flex justify-between text-[10px] font-black text-[#C9A227] uppercase"><span>Discount</span><span>-{fmtMoney(discountAmt, form.currency)}</span></div>}
                            <div className="flex justify-between text-[10px] font-black text-emerald-600 uppercase"><span>Paid</span><span>{fmtMoney(totalPaidInForm, form.currency)}</span></div>
                            <div className="flex justify-between items-center pt-2.5 border-t border-[#0A1830] mt-2">
                              <span className="text-[11px] font-black italic opacity-60 uppercase">Balance</span>
                              <div className="text-xl font-black tracking-tighter">{fmtMoney(balanceDue, form.currency)}</div>
                            </div>
                          </div>
                        </div>
                      </section>
                    </div>
                  </div>
                )}
                {(viewMode === 'preview' || viewMode === 'split') && (
                  <div className="flex-1 flex justify-center items-start overflow-y-auto p-4 sm:p-12 bg-[#F0F3F9]">
                    <div className="w-full flex justify-center py-6">{renderInvoiceView()}</div>
                  </div>
                )}
              </div>
            )}

            {activePage === 'expenses' && (
              <div className="p-3 sm:p-5 w-full max-w-[1000px] mx-auto space-y-6">
                <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
                  <h3 className="text-[12px] font-black text-slate-400 uppercase tracking-widest">បញ្ចូលចំណាយ · Add Expense</h3>
                  <FieldLabel labelKh="បរិយាយ" labelEn="Description"><input value={expenseForm.description} onChange={e => setExpenseForm({ ...expenseForm, description: e.target.value })} className={inputCls} /></FieldLabel>
                  <div className="grid grid-cols-3 gap-3">
                    <FieldLabel labelKh="កាលបរិច្ឆេទ" labelEn="Date"><input type="date" value={expenseForm.date} onChange={e => setExpenseForm({ ...expenseForm, date: e.target.value })} className={inputCls} /></FieldLabel>
                    <FieldLabel labelKh="ចំនួនទឹកប្រាក់" labelEn="Amount"><input type="number" value={expenseForm.amount} onChange={e => setExpenseForm({ ...expenseForm, amount: e.target.value })} className={inputCls} /></FieldLabel>
                    <FieldLabel labelKh="រូបិយប័ណ្ណ" labelEn="Currency">
                      <select value={expenseForm.currency} onChange={e => setExpenseForm({ ...expenseForm, currency: e.target.value })} className={inputCls}>
                        {CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.symbol} {c.code}</option>)}
                      </select>
                    </FieldLabel>
                  </div>
                  <button onClick={addExpense} className="w-full py-3 rounded-xl bg-[#0A1830] text-white font-black text-[11px] uppercase tracking-widest shadow-lg active:scale-95 transition-transform hover:bg-[#12274A]">រក្សាទុក · Save Expense</button>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                  <table className="w-full text-left border-collapse">
                    <thead className="border-b border-slate-100 bg-[#F7F9FC] text-[10px] font-black uppercase tracking-widest text-slate-400">
                      <tr><th className="p-4 px-6">កាលបរិច្ឆេទ · Date</th><th className="p-4">បរិយាយ · Description</th><th className="p-4 text-right">ចំនួនទឹកប្រាក់ · Amount</th><th className="p-4 text-right pr-6"></th></tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-[13px] font-bold">
                      {expenses.length > 0 ? [...expenses].reverse().map(e => (
                        <tr key={e.id} className="hover:bg-[#F7F9FC]">
                          <td className="p-4 px-6 text-slate-400 font-mono text-[11px]">{e.date}</td>
                          <td className="p-4 uppercase">{e.description}</td>
                          <td className="p-4 text-right font-black text-rose-500">-{fmtMoney(e.amount, e.currency)}</td>
                          <td className="p-4 text-right pr-6"><button onClick={() => deleteExpense(e.id)} className="p-2 rounded-xl border border-slate-200 bg-white text-slate-300 hover:text-red-500"><Trash2 size={16} /></button></td>
                        </tr>
                      )) : <tr><td colSpan={4} className="p-16 text-center text-[12px] text-slate-300 font-black uppercase italic">No expenses yet</td></tr>}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activePage === 'ledger' && (
              <div className="p-3 sm:p-5 w-full max-w-[1400px] mx-auto">
                <div className="relative w-full sm:w-80 mb-4">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className={`pl-11 ${inputCls} shadow-sm`} />
                </div>
                <div className="rounded-xl shadow-sm border border-slate-200 bg-white overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse min-w-[900px]">
                      <thead className="border-b border-slate-100 bg-[#F7F9FC] text-[10px] font-black uppercase tracking-widest text-slate-400">
                        <tr><th className="p-4 px-6">Serial</th><th className="p-4">Customer</th><th className="p-4 text-right">Total</th><th className="p-4 text-right">Paid</th><th className="p-4 text-right">Owed</th><th className="p-4 text-center">Status</th><th className="p-4 text-right pr-10">Admin</th></tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-[13px] font-bold">
                        {invoices.length > 0 ? [...invoices].filter(i => (i.custName || '').toLowerCase().includes(searchTerm.toLowerCase())).sort((a, b) => Number(b.invoiceNo) - Number(a.invoiceNo)).map(inv => {
                          const paid = (inv.payments || []).reduce((a, p) => a + Number(p.amount), 0);
                          const bal = Number(inv.total) - paid;
                          return (
                            <tr key={inv.id} className="hover:bg-[#F7F9FC]">
                              <td className="p-4 px-6 font-mono font-black text-slate-400 text-[11px]">#{String(inv.invoiceNo).padStart(6, '0')}</td>
                              <td className="p-4 font-black text-[14px] uppercase">{inv.custName}</td>
                              <td className="p-4 text-right font-black">{fmtMoney(inv.total, inv.currency)}</td>
                              <td className="p-4 text-right font-black text-emerald-600">{fmtMoney(paid, inv.currency)}</td>
                              <td className={`p-4 text-right font-black ${bal > 0 ? 'text-rose-500' : 'text-slate-400'}`}>{fmtMoney(bal, inv.currency)}</td>
                              <td className="p-4 text-center"><span className={`px-3 py-1 rounded-xl text-[9px] font-black border ${inv.status === 'Posted' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-[#E8EEF8] text-[#2F5A96] border-[#d5e0f2]'}`}>{inv.status.toUpperCase()}</span></td>
                              <td className="p-4 text-right pr-10">
                                <div className="flex justify-end gap-2 items-center">
                                  <button onClick={() => setSettleModal({ open: true, invoice: inv, amount: 0, date: new Date().toISOString().split('T')[0], note: '' })} className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-[#2F5A96] font-black text-[10px] uppercase flex items-center gap-1.5"><Clock size={14} /> Settle</button>
                                  <button onClick={() => startEditInvoice(inv)} className="p-2 rounded-xl border border-slate-200 bg-white text-slate-400 hover:text-[#2F5A96]"><Edit3 size={16} /></button>
                                  <button onClick={() => deleteInvoice(inv)} className="p-2 rounded-xl border border-slate-200 bg-white text-slate-300 hover:text-red-500"><Trash2 size={16} /></button>
                                </div>
                              </td>
                            </tr>
                          );
                        }) : <tr><td colSpan={7} className="p-20 text-center text-[12px] text-slate-300 font-black uppercase italic">No invoices yet</td></tr>}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activePage === 'inventory' && (
              <div className="p-3 sm:p-5 w-full max-w-[1400px] mx-auto space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl border border-slate-200 bg-[#0A1830] p-4">
                    <div className="khmer text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">ស្តុកបច្ចុប្បន្ន · Current Stock</div>
                    <div className="text-2xl font-black tracking-tight text-white">{stockSummary.balancePcs} <span className="text-[11px] text-slate-400 uppercase">PCS</span></div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <div className="khmer text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">សមតុល្យ · Net Balance</div>
                    <div className={`text-2xl font-black tracking-tight ${stockSummary.balancePcs >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>{stockSummary.balancePcs >= 0 ? '+' : ''}{stockSummary.balancePcs} <span className="text-[11px] text-slate-400 uppercase">PCS</span></div>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                  <div className="flex rounded-lg border border-slate-200 overflow-hidden">
                    <button onClick={() => setStockForm({ ...stockForm, direction: 'IN' })} className={`khmer flex-1 py-2 font-bold text-[13px] ${stockForm.direction === 'IN' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-400'}`}>ស្តុកចូល · Stock In</button>
                    <button onClick={() => setStockForm({ ...stockForm, direction: 'OUT' })} className={`khmer flex-1 py-2 font-bold text-[13px] ${stockForm.direction === 'OUT' ? 'bg-rose-500 text-white' : 'bg-white text-slate-400'}`}>ស្តុកចេញ · Stock Out</button>
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldLabel labelKh="កាលបរិច្ឆេទ" labelEn="Date" size="compact"><input type="date" value={stockForm.date} onChange={e => setStockForm({ ...stockForm, date: e.target.value })} className={inputClsCompact} /></FieldLabel>
                    <FieldLabel labelKh="ចំនួន" labelEn="Quantity" size="compact"><input type="number" value={stockForm.quantity} onChange={e => setStockForm({ ...stockForm, quantity: e.target.value })} className={inputClsCompact} /></FieldLabel>
                  </div>
                  <FieldLabel labelKh="បរិយាយ" labelEn="Description" size="compact"><input value={stockForm.description} onChange={e => setStockForm({ ...stockForm, description: e.target.value })} className={inputClsCompact} /></FieldLabel>
                  <button onClick={addStockEntry} className={`khmer w-full py-2.5 rounded-lg font-bold text-[13px] text-white ${stockForm.direction === 'OUT' ? 'bg-rose-500 hover:bg-rose-600' : 'bg-emerald-600 hover:bg-emerald-700'}`}>រក្សាទុក · Save</button>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
                  <div className="khmer px-4 py-2.5 border-b border-slate-100 bg-[#F7F9FC] text-[10px] font-bold text-slate-400 uppercase tracking-wide">ប្រវត្តិ · History</div>
                  <table className="w-full text-left border-collapse">
                    <thead className="text-[9px] font-bold uppercase tracking-wide text-slate-400 border-b border-slate-100">
                      <tr><th className="p-2.5 px-4">Date</th><th className="p-2.5">Description</th><th className="p-2.5 text-right pr-4">Qty</th></tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-[12.5px] font-semibold">
                      {stockLogs.length > 0 ? [...stockLogs].reverse().map(l => (
                        <tr key={l.id}>
                          <td className="p-2.5 px-4 text-slate-400 font-mono text-[10.5px]">{l.date}</td>
                          <td className="p-2.5">{l.note}</td>
                          <td className={`p-2.5 text-right pr-4 font-black ${Number(l.quantity) < 0 ? 'text-rose-500' : 'text-emerald-600'}`}>{Number(l.quantity) > 0 ? `+${l.quantity}` : l.quantity}</td>
                        </tr>
                      )) : <tr><td colSpan={3} className="p-8 text-center text-[11px] text-slate-300 font-bold uppercase italic">No stock history yet</td></tr>}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activePage === 'settings' && settingsForm && (
              <div className="p-3 sm:p-5 w-full max-w-lg mx-auto space-y-5">
                <h2 className="text-lg font-black tracking-tight flex items-center gap-2"><Settings size={18} className="text-[#2F5A96]" /> ការកំណត់ · Settings</h2>
                <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-sm">
                  <FieldLabel labelKh="ឈ្មោះអាជីវកម្ម" labelEn="Business Name"><input value={settingsForm.businessName} onChange={e => setSettingsForm({ ...settingsForm, businessName: e.target.value })} className={inputCls} /></FieldLabel>
                  <FieldLabel labelKh="ឈ្មោះម្ចាស់" labelEn="Owner Name"><input value={settingsForm.ownerName} onChange={e => setSettingsForm({ ...settingsForm, ownerName: e.target.value })} className={inputCls} /></FieldLabel>
                  <FieldLabel labelKh="លេខទូរស័ព្ទ" labelEn="Phone"><input value={settingsForm.phone} onChange={e => setSettingsForm({ ...settingsForm, phone: e.target.value })} className={inputCls} /></FieldLabel>
                  <FieldLabel labelKh="គណនីទទួលប្រាក់" labelEn="Payment Account"><input value={settingsForm.payAccount} onChange={e => setSettingsForm({ ...settingsForm, payAccount: e.target.value })} className={inputCls} /></FieldLabel>
                  <div className="grid grid-cols-2 gap-3">
                    <FieldLabel labelKh="អត្រា KHR" labelEn="Rate per $1"><input type="number" value={settingsForm.rates?.KHR ?? DEFAULT_RATES.KHR} onChange={e => setSettingsForm({ ...settingsForm, rates: { ...settingsForm.rates, KHR: Number(e.target.value) } })} className={inputCls} /></FieldLabel>
                    <FieldLabel labelKh="អត្រា THB" labelEn="Rate per $1"><input type="number" value={settingsForm.rates?.THB ?? DEFAULT_RATES.THB} onChange={e => setSettingsForm({ ...settingsForm, rates: { ...settingsForm.rates, THB: Number(e.target.value) } })} className={inputCls} /></FieldLabel>
                  </div>
                  <FieldLabel labelKh="ពាក្យសម្ងាត់" labelEn="Password"><input type="password" value={settingsForm.password} onChange={e => setSettingsForm({ ...settingsForm, password: e.target.value })} className={inputCls} /></FieldLabel>
                  <FieldLabel labelKh="រូបភាព QR បង់ប្រាក់" labelEn="Payment QR Code Image">
                    <div className="flex items-center gap-4">
                      {settingsForm.qrImage ? <img src={settingsForm.qrImage} alt="QR preview" className="w-20 h-20 rounded-xl border-2 border-[#E8EEF8] object-contain" /> : <div className="w-20 h-20 rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center text-slate-300"><QrCode size={24} /></div>}
                      <label className="flex-1 cursor-pointer">
                        <div className="flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed border-[#2F5A96]/30 text-[#2F5A96] font-black text-[11px] uppercase tracking-wide hover:bg-[#E8EEF8]/40 transition-colors">
                          <ImageIcon size={14} /> {settingsForm.qrImage ? 'ប្តូររូបភាព · Change' : 'ជ្រើសរូបភាព · Select Photo'}
                        </div>
                        <input type="file" accept="image/*" onChange={handleQrUpload} className="hidden" />
                      </label>
                    </div>
                  </FieldLabel>
                  <button onClick={saveSettings} className="w-full py-3.5 rounded-xl bg-[#0A1830] text-white font-black text-[12px] uppercase tracking-widest shadow-lg active:scale-95 transition-transform hover:bg-[#12274A]">រក្សាទុក · Save Settings</button>
                  <button onClick={handleLogout} className="w-full py-3 rounded-xl bg-white border-2 border-rose-200 text-rose-500 font-black text-[11px] uppercase tracking-widest active:scale-95 transition-transform hover:bg-rose-50">ចាកចេញ · Log Out</button>
                </div>
              </div>
            )}
          </div>
        </main>

        {settleModal.open && (
          <div className="fixed inset-0 z-[4000] flex items-center justify-center p-4 bg-[#050B16]/80 backdrop-blur-sm">
            <div className="bg-white w-full max-w-sm rounded-[28px] shadow-2xl overflow-hidden">
              <div className="p-7">
                <div className="flex items-center gap-3 mb-5"><div className="w-10 h-10 bg-[#E8EEF8] rounded-2xl flex items-center justify-center text-[#2F5A96]"><BadgeDollarSign size={20} /></div><h3 className="text-lg font-black uppercase tracking-tight">ថតការទូទាត់ · Record Payment</h3></div>
                <div className="space-y-4">
                  <FieldLabel labelKh="កាលបរិច្ឆេទ" labelEn="Date"><input type="date" value={settleModal.date} onChange={e => setSettleModal({ ...settleModal, date: e.target.value })} className={inputCls} /></FieldLabel>
                  <FieldLabel labelKh="ចំនួនទឹកប្រាក់" labelEn="Amount"><input type="number" value={settleModal.amount} onChange={e => setSettleModal({ ...settleModal, amount: e.target.value })} className="w-full p-4 rounded-2xl font-black text-[#2F5A96] text-2xl outline-none border border-slate-200 shadow-inner focus:border-[#2F5A96]" /></FieldLabel>
                  <FieldLabel labelKh="កំណត់ចំណាំ" labelEn="Note"><input value={settleModal.note} onChange={e => setSettleModal({ ...settleModal, note: e.target.value })} className={inputCls} /></FieldLabel>
                </div>
              </div>
              <div className="p-4 bg-[#F7F9FC] flex gap-2">
                <button onClick={() => setSettleModal({ open: false, invoice: null, amount: 0, date: new Date().toISOString().split('T')[0], note: '' })} className="flex-1 py-3 rounded-xl font-black text-[11px] text-slate-500 hover:bg-slate-200 uppercase">Cancel</button>
                <button onClick={commitPayment} className="flex-1 py-3 rounded-xl font-black text-[11px] text-white bg-[#0A1830] hover:bg-[#12274A] shadow-xl uppercase tracking-widest">Commit</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
